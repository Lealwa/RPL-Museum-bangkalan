<style>
    .footer{
        margin-top: 80px;
    }
</style>

<div class="footer">
    <img src="img/Footer.png" alt="Footer Image">
</div>